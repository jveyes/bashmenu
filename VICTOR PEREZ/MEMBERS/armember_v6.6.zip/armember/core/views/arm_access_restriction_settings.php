<?php
global $wpdb, $ARMember, $arm_global_settings, $arm_access_rules, $arm_subscription_plans, $arm_restriction ,$arm_drip_rules;
$all_global_settings = $arm_global_settings->arm_get_all_global_settings();

$general_settings = $all_global_settings['general_settings'];
$page_settings = $all_global_settings['page_settings'];
$general_settings['hide_feed'] = isset($general_settings['hide_feed']) ? $general_settings['hide_feed'] : 0;
$all_plans_data = $arm_subscription_plans->arm_get_all_subscription_plans('arm_subscription_plan_id, arm_subscription_plan_name, arm_subscription_plan_type', ARRAY_A, true);
$defaultRulesTypes = $arm_access_rules->arm_get_access_rule_types();
$default_rules = $arm_access_rules->arm_get_default_access_rules();
$all_roles = $arm_global_settings->arm_get_all_roles();
$is_restricted_admin_panel_checked = ($general_settings['restrict_admin_panel'] == 1) ? 'checked="checked"' : '';
$arm_restriction_settings = '<table class="form-table">
    <tr class="form-field">
        <th class="arm-form-table-label">'. esc_html__('Restrict admin panel','ARMember').'</th>
        <td class="arm-form-table-content">
            <div class="armswitch arm_global_setting_switch">
                <input type="checkbox" id="restrict_admin_panel" '.$is_restricted_admin_panel_checked.' value="1" class="armswitch_input" name="arm_general_settings[restrict_admin_panel]"/>
                <label for="restrict_admin_panel" class="armswitch_label"></label>
            </div>
            <label for="restrict_admin_panel" class="arm_global_setting_switch_label">'. esc_html__('Restrict admin panel for non-admin users','ARMember').'</label>
        </td>
    </tr>';
    $restrict_admin_panel_section = ($general_settings['restrict_admin_panel'] == '1') ? '' : ' hidden_section';     
    $arm_restriction_settings .= '<tr class="form-field arm_exclude_role_for_restrict_admin '.$restrict_admin_panel_section.'">
        <th class="arm-form-table-label">'. esc_html__('Exclude role for restriction','ARMember').'</th>
                            <td class="arm-form-table-content">';
                                $arm_exclude_role_for_restrict_admin = isset($general_settings['arm_exclude_role_for_restrict_admin']) ? explode(',', $general_settings['arm_exclude_role_for_restrict_admin']) : array();
                                $arm_restriction_settings .= '<select id="arm_access_page_for_restrict_site" class="arm_chosen_selectbox arm_width_500" name="arm_general_settings[arm_exclude_role_for_restrict_admin][]" data-placeholder="'. esc_attr__('Select Role(s)..', 'ARMember').'" multiple="multiple" >';
                                        if (!empty($all_roles)){
                                            foreach ($all_roles as $role_key => $role_value) {
                                                $selected_roles = (in_array($role_key, $arm_exclude_role_for_restrict_admin)) ? ' selected="selected"' : '';
                                                $arm_restriction_settings .= '<option class="arm_message_selectbox_op" value="'. esc_attr($role_key).'" '.$selected_roles.'>'. stripslashes($role_value) .'</option>';
                                            }
                                        }
                                        else
                                        {
                                            $arm_restriction_settings .= '<option value="">'. esc_html__('No Pages Available', 'ARMember').'</option>';
                                        }
                                        $arm_restriction_settings .= '</select>
                                <span class="arm_info_text arm_info_text_style" >
                                    ('. esc_html__('Selected roles will be able to access admin.','ARMember').')
                                </span>
                            </td>
    </tr>';
    $is_hidden_field_checked = ($general_settings['hide_feed'] == 1) ? 'checked="checked"' : '';
    $arm_restriction_settings .= '<tr class="form-field">
        <th class="arm-form-table-label">'. esc_html__('Block RSS feeds', 'ARMember').'</th>
        <td class="arm-form-table-content">
            <div class="armswitch arm_global_setting_switch">
                <input type="checkbox" id="hide_feed" '. $is_hidden_field_checked.' value="1" class="armswitch_input" name="arm_general_settings[hide_feed]"/>
                <label for="hide_feed" class="armswitch_label"></label>
            </div>
            <label for="hide_feed" class="arm_global_setting_switch_label">'. esc_html__('Disable feeds access to everyone','ARMember').'</label>
        </td>
    </tr>';
    $rtl_float = (is_rtl()) ? 'right' : 'left';
    $rtl_margin = (is_rtl()) ? '7px 0 0 10px' : '7px 10px 0 0';
    $is_restricted_site_access = ($general_settings['restrict_site_access'] == 1) ? 'checked="checked"' :'';
    $restrict_site_access = ($general_settings['restrict_site_access'] == 1) ? '':'hidden_section';
    $arm_restriction_settings .= '<tr class="form-field">
        <th class="arm-form-table-label">'. esc_html__('Restrict entire website without login','ARMember').'</th>
        <td class="arm-form-table-content">						
            <div class="armswitch arm_global_setting_switch" style="display: inline-block;float: '. $rtl_float.';margin: '. $rtl_margin .';">
                <input type="checkbox" id="restrict_site_access" '.$is_restricted_site_access.' value="1" class="armswitch_input" name="arm_general_settings[restrict_site_access]"/>
                <label for="restrict_site_access" class="armswitch_label"></label>
            </div>
            <div class="restrict_site_access '.$restrict_site_access.'">
                <div class="arm_info_text arm_margin_bottom_20" style="">'. esc_html__('If website is restricted, redirect visitor to following page','ARMember').':</div>';

                $arm_restriction_settings .= $arm_global_settings->arm_wp_dropdown_pages(
                    array(
                        'selected'              => isset($page_settings['guest_page_id']) ? $page_settings['guest_page_id'] : 0,
                        'name'                  => 'arm_page_settings[guest_page_id]',
                        'id'                    => 'guest_page_id',
                        'show_option_none'      => esc_html__('Select Page','ARMember'),
                        'option_none_value'     => '0',
                        'echo'                  => 0,
                        'class'     => 'arm_regular_select',
                    )
                );
                $arm_restriction_settings .= '<span id="guest_page_id_error" class="arm_error_msg guest_page_id_error" style="display:none;">'.esc_html__('Please select guest page.', 'ARMember').'</span>
            </div>
        </td>
    </tr>';
    $restrict_site_css = ($general_settings['restrict_site_access'] != 1) ? 'style="display:none;"' : '';
    $arm_restriction_settings .='<tr class="form_field page_access_for_restrict_site" '.$restrict_site_css.'>
        <th class="arm-form-table-label">'. esc_html__('Exclude pages for restriction','ARMember').'</th>
        <td class="arm-form-table-content">';
            $defaults = array(
                    'depth' => 0, 'child_of' => 0,
                    'selected' => 0, 'echo' => 1,
                    'name' => 'page_id', 'id' => '',
                    'show_option_none' => 'Select Page', 'show_option_no_change' => '',
                    'option_none_value' => '',
                    'class' => '',
                    'required' => false,
                    'required_msg' => false,
            );
            $pages = get_pages($defaults);
            $arm_sel_access_page_for_restrict_site = array();
            if(isset($page_settings['arm_access_page_for_restrict_site']))
            {
                $arm_sel_access_page_for_restrict_site = explode(',', $page_settings['arm_access_page_for_restrict_site']);
            }
            $global_setting_page = $arm_global_settings->arm_get_single_global_settings('page_settings');
            $allow_page_ids = $arm_restriction->arm_filter_allow_page_ids($global_setting_page);
            $is_allow_content_listed_checked = ($default_rules['arm_allow_content_listing'] == 1) ? "checked='checked'" : '';
            $arm_restriction_settings .='<select id="arm_access_page_for_restrict_site" class="arm_chosen_selectbox arm_width_500" name="arm_general_settings[arm_access_page_for_restrict_site][]" data-placeholder="'. esc_attr__('Select Page(s)..', 'ARMember').'" multiple="multiple" >';
                        if (!empty($pages)){
                            foreach ($pages as $p) {
                                if(in_array($p->ID, $allow_page_ids)){ continue; }
                                $selected_pages = (in_array($p->ID, $arm_sel_access_page_for_restrict_site)) ? ' selected="selected"' : '';
                                $arm_restriction_settings .='<option class="arm_message_selectbox_op" value="'. esc_attr($p->ID).'" '. $selected_pages .'>'. stripslashes($p->post_title).'</option>';
                            }
                        }
                        else{

                            $arm_restriction_settings .='<option value="">'. esc_html__('No Pages Available', 'ARMember').'</option>';
                        }
                        $arm_restriction_settings .='</select>
            <span class="arm_info_text arm_info_text_style">
                ('. esc_html__('Selected pages will be accessible to users without login.','ARMember') .')
            </span>
        </td>
    </tr>
    
    <tr class="form-field">
            <th class="arm-form-table-label">'. esc_html__('Allow restricted Pages/Posts in listing', 'ARMember').'</th>
            <td class="arm-form-table-content">
                <div class="armswitch arm_global_setting_switch">
                        <input type="checkbox" id="arm_allow_content_listing" value="1" class="armswitch_input" name="arm_default_rules[arm_allow_content_listing]" '. $is_allow_content_listed_checked .'/>
                        <label for="arm_allow_content_listing" class="armswitch_label"></label>
                </div>
                <span class="arm_info_text arm_info_text_style">
                    ('. esc_html__('If you enable this switch than, restricted content will be displayed in listing only.','ARMember') .')
                </span>
            </td>
    </tr>
    
</table>';