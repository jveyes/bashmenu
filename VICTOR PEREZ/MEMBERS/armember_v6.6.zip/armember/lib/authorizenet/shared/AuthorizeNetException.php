<?php
/**
 * AuthorizeNetException.php
 *
 * @package AuthorizeNet
 */

/**
 * Exception class for AuthorizeNet PHP SDK.
 *
 * @package AuthorizeNet
 */
class AuthorizeNetException extends Exception
{
}
