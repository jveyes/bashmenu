<?php
global $wpdb, $ARMember, $armemail, $armfname, $armlname, $form_id, $arm_social_feature, $arm_is_social_signup,$arm_email_settings;
$email_settings_unser = $arm_email_settings->arm_get_all_email_settings();
$arm_email_settings_data = maybe_unserialize($email_settings_unser);
$aweberOpt = (isset($arm_email_settings_data['arm_email_tools']['aweber'])) ? $arm_email_settings_data['arm_email_tools']['aweber'] : array();
$temp_data = maybe_unserialize(get_option('arm_aweber_temp_credential'));
$list_id = (isset($aweberOpt['list_id'])) ? $aweberOpt['list_id'] : '';
$responder_list_id = '';
if($arm_is_social_signup){
    $social_settings = !empty($arm_social_feature->social_settings) ? $arm_social_feature->social_settings : array();
    if(isset($social_settings['options']['optins_name']) && $social_settings['options']['optins_name'] == 'aweber') {
        $etool_name = isset($social_settings['options']['optins_name']) ? $social_settings['options']['optins_name'] : '';
        $status = 1;
        $responder_list_id = isset($social_settings['options'][$etool_name]['list_id']) ? $social_settings['options'][$etool_name]['list_id'] : $list_id ;
    }
}
else
{
    $form_settings = $wpdb->get_var("SELECT `arm_form_settings` FROM `" . $ARMember->tbl_arm_forms . "` WHERE `arm_form_id`='" . $form_id . "'");
    $form_settings = (!empty($form_settings)) ? maybe_unserialize($form_settings) : array();
    $status = (isset($form_settings['email']['aweber']['status'])) ? $form_settings['email']['aweber']['status'] : 0;
    $responder_list_id = (isset($form_settings['email']['aweber']['list_id'])) ? $form_settings['email']['aweber']['list_id'] : $list_id;
}
if (!empty($responder_list_id))
{
	if ($status == '1' && !empty($responder_list_id))
	{
		if( false == get_transient('arm_aweber_access_token') ){
			$temp_data = $arm_email_settings->arm_aweber_refresh_token();
		}
		$accessToken    = $temp_data['accessToken'];		 	# put your credentials here
		$account_id     = $temp_data['acc_id']; 				# put the Account ID here
		$aweber_list_id = $responder_list_id; 					# put the List ID here
		$refreshToken 	= $temp_data['refreshToken'];
		
		if ( empty( $armemail ) ) {
			return 'No email address provided';
		}

		if ( ! preg_match( '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*$/i', $armemail ) ) {
			return 'Email address is invalid';
		}

		$add_sub_url = "https://api.aweber.com/1.0/accounts/".$account_id."/lists/".$aweber_list_id."/subscribers"; 
		$sub_headers = array(
					'Content-Type' => 'application/json',
				    'Authorization' => 'Bearer ' . $accessToken,
				   );
		$params = array(
				'email' => $armemail,
				'name' => $armfname . " " . $armlname,
			);
		$params = json_encode($params);
		do_action('arm_general_log_entry', 'aweber', 'subscriber parameters', 'armember', $params);

		$request_string = array(
			'method' => 'POST',
			'headers' => $sub_headers,
			'body' => $params,
			'timeout' => 5000
		); 	
		

		$add_subscriber = wp_remote_post( $add_sub_url, $request_string );

		if(is_wp_error( $add_subscriber ))
		{
			do_action('arm_general_log_entry', 'aweber', 'subscriber add response Error', 'armember', $add_subscriber->get_error_message());
		}
		else
		{
			do_action('arm_general_log_entry', 'aweber', 'subscriber add response Success', 'armember', $add_subscriber);
		}
		return;
			# success!
			/*print "A new subscriber was added to the $list->name list!";*/
	}
}
?>