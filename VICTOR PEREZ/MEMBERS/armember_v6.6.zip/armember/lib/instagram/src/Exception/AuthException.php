<?php namespace Andreyco\Instagram\Exception;

use Exception;

class AuthException extends Exception {}
