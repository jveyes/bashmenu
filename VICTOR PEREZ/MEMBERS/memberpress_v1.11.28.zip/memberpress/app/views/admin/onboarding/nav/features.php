<?php if(!defined('ABSPATH')) {die('You are not allowed to call this page directly.');} ?>
<div>
  <button type="button" id="mepr-wizard-save-features" class="mepr-wizard-button-blue"><?php esc_html_e('Continue', 'memberpress'); ?></button>
</div>
