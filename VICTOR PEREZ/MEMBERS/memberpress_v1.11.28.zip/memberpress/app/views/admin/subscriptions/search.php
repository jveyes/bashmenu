<?php foreach( $subs as $sub ) { echo "{$sub->subscr_id}\n"; }
