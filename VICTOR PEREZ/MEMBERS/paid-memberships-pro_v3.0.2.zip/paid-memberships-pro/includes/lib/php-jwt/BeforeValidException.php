<?php
namespace Firebase\JWT;

class BeforeValidException extends \UnexpectedValueException
{

}
