jQuery(function ($) {
    "user strict";

    $(".redux-container-ct_iconpicker .ct-iconpicker").fontIconPicker();
});