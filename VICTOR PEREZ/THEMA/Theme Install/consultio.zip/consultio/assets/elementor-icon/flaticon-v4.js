{
    "icons": [
    "doctor",
    "panic-1",
    "clean",
    "keep-distance",
    "cleaner",
    "sweeping",
    "next",
    "arrow",
    "bar-graph",
    "refresh",
    "grow-shop",
    "interest"
]
}