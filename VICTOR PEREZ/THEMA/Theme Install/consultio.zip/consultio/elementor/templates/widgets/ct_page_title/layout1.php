<?php $titles = consultio_get_page_titles(); ?>
<h1 class="ct-page-title"><?php echo wp_kses_post($titles['title']) ?></h1>